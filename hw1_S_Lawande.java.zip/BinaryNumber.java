
public class BinaryNumber {

}
